package com.example.weighttrackerpro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private ArrayList<WeightEntry> weightEntries;
    private OnWeightClickListener onWeightClickListener;

    public interface OnWeightClickListener {
        void onWeightClick(WeightEntry weightEntry);  // For editing
        void onDeleteClick(WeightEntry weightEntry);  // For deletion
    }

    public WeightAdapter(ArrayList<WeightEntry> weightEntries, OnWeightClickListener listener) {
        this.weightEntries = weightEntries;
        this.onWeightClickListener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_item, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.dateTextView.setText(entry.getDate());
        holder.weightTextView.setText(String.valueOf(entry.getWeight()));

        // Handle item click for editing
        holder.itemView.setOnClickListener(v -> onWeightClickListener.onWeightClick(entry));

        // Handle delete button click
        holder.deleteButton.setOnClickListener(v -> onWeightClickListener.onDeleteClick(entry));  // Delete action
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;
        View deleteButton;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);  // Reference delete button
        }
    }
}
