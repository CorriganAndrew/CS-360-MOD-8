package com.example.weighttrackerpro;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {

    // Declare UI components and DatabaseHelper
    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Set a click listener for the login button
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            } else {
                // Check if the user exists in the database
                if (databaseHelper.checkUser(username, password)) {
                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                    // Navigate to WeightTrackingActivity after successful login
                    Intent intent = new Intent(MainActivity.this, WeightTrackingActivity.class);
                    startActivity(intent);
                } else {
                    // If user doesn't exist, add the user to the database
                    databaseHelper.addUser(username, password);
                    Toast.makeText(MainActivity.this, "New user created! Login successful", Toast.LENGTH_SHORT).show();

                    // Navigate to WeightTrackingActivity after new user creation
                    Intent intent = new Intent(MainActivity.this, WeightTrackingActivity.class);
                    startActivity(intent);
                }
            }
        });

    }
}
