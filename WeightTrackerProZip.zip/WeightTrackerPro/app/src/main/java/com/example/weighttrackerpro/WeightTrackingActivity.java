package com.example.weighttrackerpro;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.telephony.SmsManager;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class WeightTrackingActivity extends AppCompatActivity implements WeightAdapter.OnWeightClickListener {

    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS_NAME = "WeightTrackerPrefs";
    private static final String KEY_GOAL_WEIGHT = "goalWeight";

    private EditText weightInput;
    private Button saveWeightButton, setGoalWeightButton;
    private RecyclerView weightRecyclerView;
    private DatabaseHelper databaseHelper;
    private WeightAdapter adapter;
    private WeightEntry selectedWeightEntry;
    private SharedPreferences sharedPreferences;
    private float goalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        weightInput = findViewById(R.id.weightInput);
        saveWeightButton = findViewById(R.id.saveWeightButton);
        setGoalWeightButton = findViewById(R.id.setGoalWeightButton);
        weightRecyclerView = findViewById(R.id.weightRecyclerView);

        databaseHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Load saved goal weight
        goalWeight = sharedPreferences.getFloat(KEY_GOAL_WEIGHT, -1);

        // Set up RecyclerView
        weightRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        displayWeights();  // Display the stored weights

        // Save or update weight entry on button click
        saveWeightButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString();
            if (!weightStr.isEmpty()) {
                float weight = Float.parseFloat(weightStr);
                String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                if (selectedWeightEntry != null) {
                    // Update existing weight
                    databaseHelper.updateWeight(selectedWeightEntry.getId(), weight, currentDate);
                    Toast.makeText(WeightTrackingActivity.this, "Weight updated!", Toast.LENGTH_SHORT).show();
                    selectedWeightEntry = null;  // Reset the selected entry
                } else {
                    // Add new weight
                    databaseHelper.addWeight(weight, currentDate);
                    Toast.makeText(WeightTrackingActivity.this, "Weight saved!", Toast.LENGTH_SHORT).show();
                }

                // Check if the weight meets the goal and send an SMS if it does
                if (goalWeight > 0 && weight <= goalWeight) {
                    sendSms("Congratulations! You have reached your goal weight of " + goalWeight + "!");
                }

                displayWeights();  // Refresh list
                weightInput.setText("");  // Clear input field
            } else {
                Toast.makeText(WeightTrackingActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        // Set or update goal weight
        setGoalWeightButton.setOnClickListener(v -> {
            EditText goalWeightInput = new EditText(WeightTrackingActivity.this);
            goalWeightInput.setHint("Enter your goal weight");

            // Allow user to enter a goal weight
            new androidx.appcompat.app.AlertDialog.Builder(WeightTrackingActivity.this)
                    .setTitle("Set Goal Weight")
                    .setView(goalWeightInput)
                    .setPositiveButton("Save", (dialog, which) -> {
                        String goalWeightStr = goalWeightInput.getText().toString();
                        if (!goalWeightStr.isEmpty()) {
                            goalWeight = Float.parseFloat(goalWeightStr);
                            sharedPreferences.edit().putFloat(KEY_GOAL_WEIGHT, goalWeight).apply();
                            Toast.makeText(WeightTrackingActivity.this, "Goal weight set to " + goalWeight, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(WeightTrackingActivity.this, "Please enter a valid goal weight", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Request SMS permission
        requestSmsPermission();
    }

    private void displayWeights() {
        Cursor cursor = databaseHelper.getAllWeights();
        ArrayList<WeightEntry> weightEntries = new ArrayList<>();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            float weight = cursor.getFloat(cursor.getColumnIndexOrThrow("weight"));
            weightEntries.add(new WeightEntry(id, date, weight));
        }

        adapter = new WeightAdapter(weightEntries, this);  // Pass 'this' for the click listener
        weightRecyclerView.setAdapter(adapter);
    }

    @Override
    public void onWeightClick(WeightEntry weightEntry) {
        selectedWeightEntry = weightEntry;
        weightInput.setText(String.valueOf(weightEntry.getWeight()));  // Fill input for editing
    }

    @Override
    public void onDeleteClick(WeightEntry weightEntry) {
        databaseHelper.deleteWeight(weightEntry.getId());
        displayWeights();  // Refresh list after deletion
        Toast.makeText(WeightTrackingActivity.this, "Weight deleted!", Toast.LENGTH_SHORT).show();
    }

    // Request SMS permission from the user
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Method to send SMS
    private void sendSms(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("phone_number_here", null, message, null, null);  // Replace with actual phone number
            Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS Permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the result of permission requests
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
