package com.example.weighttrackerpro;

public class WeightEntry {
    private int id;  // Add the id field to track each entry's unique id
    private String date;
    private float weight;

    public WeightEntry(int id, String date, float weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public float getWeight() {
        return weight;
    }

    // Optionally, you could add setter methods if needed
    public void setId(int id) {
        this.id = id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }
}
